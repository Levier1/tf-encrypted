Bloom's method
==================================
TODO(zjn): update to based on tensorflow 2
