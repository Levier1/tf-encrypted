# Private Training with tfe.keras

This directory contains a notebook demonstrating how you can train a simple model with tfe.keras. 