"""Dataset API."""
from .write_record import write_record

__all__ = [
    "write_record",
]
